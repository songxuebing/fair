<script type="text/javascript">
	//initiating jQuery
	jQuery(function($) {
	    $(document).ready( function() {
	        //enabling stickUp on the '.navbar-wrapper' class
	        $('.navbar-wrapper').stickUp();
	    });
	  });
</script>